/* Fuente:
https://github.com/hedzr/android-file-chooser

- Actualizacion: 2022
- Actualizacion: 2023 (Cambios leves en sintaxis que fatidian el día)

Paso 0:
Modificar el archivo settigs.gradle para agregar
maven { url = uri("https://www.jitpack.io" ) }
en la seccion dependencyResolutionManagement
Ver ejemplo:
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://www.jitpack.io" ) }
    }
}
Paso 1:
Agregar en la seccion dependencies la siguiente linea y sincronizar el proeycto
implementation ("com.github.hedzr:android-file-chooser:v1.2.0-final")

Paso 2:
Agregar los permisos al archivo MANIFEST
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"></uses-permission>

Paso 3:
Uan vez instalada la aplicacion, cambiar el permiso para  "Permitir administracion de todos los archivos"

 */

package com.example.selecciondearchivos;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Environment;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.obsez.android.lib.filechooser.ChooserDialog;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    final String startingDir = Environment.getExternalStorageDirectory().toString();
    final String path = Environment.getExternalStorageDirectory().toString();
    TextView TV1, TV2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TV1 = findViewById(R.id.tv_ultimo_archivo_abierto);
        TV2 = findViewById(R.id.tv_contenido_archivo);
        TV2.setMovementMethod(new ScrollingMovementMethod()); // Para hacer el TV2 "Scrollable"
    }

    public void SeleccionarImagen (View v) {
        new ChooserDialog(MainActivity.this)
                .withFilter(false, false, "jpg", "jpeg", "png")
                .withStartFile(path)
                .withChosenListener(new ChooserDialog.Result() {
                    @Override
                    public void onChoosePath(String path, File pathFile) {
                        TV1.setText(path);
                        TV2.setText("");
                        Toast.makeText(MainActivity.this, "FILE: " + path, Toast.LENGTH_SHORT).show();
                    }
                })
                .build()
                .show();
    }

    public void SeleccionarFolder (View v) {
        new ChooserDialog(MainActivity.this)
                .withFilter(true, false)
                .withStartFile(startingDir)
                // to handle the result(s)
                .withChosenListener(new ChooserDialog.Result() {
                    @Override
                    public void onChoosePath(String path, File pathFile) {
                        TV1.setText(path);
                        TV2.setText("");
                        Toast.makeText(MainActivity.this, "FOLDER: " + path, Toast.LENGTH_SHORT).show();
                    }
                })
                .build()
                .show();
    }

    public void SeleccionarPDF (View v) {
        new ChooserDialog(MainActivity.this)
                .withStartFile(path)
                .withFilter(false, false, "pdf")
                .withChosenListener(new ChooserDialog.Result() {
                    @Override
                    public void onChoosePath(String path, File pathFile) {
                        TV1.setText(path);
                        TV2.setText("");
                        Toast.makeText(MainActivity.this, "FILE: " + path, Toast.LENGTH_SHORT).show();
                    }
                })
                // to handle the back key pressed or clicked outside the dialog:
                .withOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialog) {
                        Log.d("CANCEL", "CANCEL");
                        dialog.cancel(); // MUST have
                    }
                })
                .build()
                .show();
    }

    public void SeleccionarTXT (View v) {
        new ChooserDialog(MainActivity.this)
                .withFilterRegex(false, false, ".*\\.(txt)")
                .withStartFile(path)
                //.withResources(R.string.title_choose_file, R.string.title_choose, R.string.dialog_cancel)
                .withChosenListener(new ChooserDialog.Result() {
                    @Override
                    public void onChoosePath(String path, File pathFile) {
                        Toast.makeText(MainActivity.this, "FILE: " + path, Toast.LENGTH_SHORT).show();
                        // Funcion para leer archivo
                        //String Contenido="";
                        TV1.setText(path);
                        String Contenido= null;
                        try {
                            Contenido = LeerArchivoTexto(path);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        TV2.setText(Contenido);
                    }
                })
                .build()
                .show();
    }

    private String LeerArchivoTexto (String Ruta) throws IOException {
        //Ruta= Environment.getExternalStorageDirectory().getAbsolutePath().toString()+"/"+NombreDirectorio;
        String aBuffer ="";
        String aDataRow ="";
        File F = new File (Ruta);
        if (F.exists()) { // Ya existe el directorio
            FileInputStream fIn = new FileInputStream(F);
            BufferedReader myReader = new BufferedReader(
                    new InputStreamReader(fIn));
            aDataRow = "";
            aBuffer = "";
            while ((aDataRow = myReader.readLine()) != null) {
                aBuffer += aDataRow + "\n";
            }
            myReader.close();
            Toast.makeText(getBaseContext(),
                    "Se leyó el archivo",
                    Toast.LENGTH_SHORT).show();
        }
        return (aBuffer);
    }
}